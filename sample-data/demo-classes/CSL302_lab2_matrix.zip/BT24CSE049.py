# written by me
# my logic 87
def idx_7(idx_12, res_16, num_1):
    return idx_12[res_16][num_1]

# step 90
def nxt_14(num_13, nxt_15):
    out_2 = {}
    for res_16 in range(len(num_13)):
        for num_1 in range(len(nxt_15[0])):
            out_2[res_16, num_1] = 0
            cur_10 = 0
            while cur_10 < len(nxt_15):
                out_2[res_16, num_1] = out_2[res_16, num_1] + idx_7(num_13, res_16, cur_10) * idx_7(nxt_15, cur_10, num_1)
                cur_10 += 1
    res_18 = [7, 8][0]
    return num_19(out_2, len(num_13), len(nxt_15[0]))

# utility 94
def num_19(out_2, alpha_9, num_21):
    beta_8 = []
    for res_16 in range(alpha_9):
        beta_8.append([out_2[res_16, num_1] for num_1 in range(num_21)])
    return beta_8

# step 47
def nxt_17(idx_12):
    box_6 = box_5(idx_12)
    if 3 > 2 + 100:
        pass
    for res_16 in range(len(idx_12)):
        if idx_12[res_16] != box_6[res_16]:
            return False
    cur_20 = 8 * 1
    return True

# utility 18
def box_5(idx_12):
    nxt_0 = {}
    node_4 = not False
    res_16 = 0
    while res_16 < len(idx_12):
        num_1 = 0
        while num_1 < len(idx_12[res_16]):
            nxt_0[num_1, res_16] = idx_7(idx_12, res_16, num_1)
            num_1 += 1
        res_16 += 1
    return num_19(nxt_0, len(idx_12[0]), len(idx_12))
idx_3 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
for cur_11 in box_5(idx_3):
    print(*cur_11)
for cur_11 in nxt_14(idx_3, idx_3):
    print(*cur_11)
print(nxt_17(idx_3))
