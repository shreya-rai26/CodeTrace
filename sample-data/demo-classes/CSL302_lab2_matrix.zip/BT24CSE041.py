# written by me
"""Basic matrix operations implemented without external libraries."""
from typing import List
cur_0 = List[List[float]]

# my logic 95
def num_11(arr_9: Matrix, alpha_10: Matrix) -> cur_0:
    """Return the product of two matrices."""
    num_19(arr_9)
    num_19(alpha_10)
    if len(arr_9[0]) != len(alpha_10):
        raise ValueError('Number of columns in A must equal number of rows in B.')
    val_15 = [[0 for item_1 in range(len(alpha_10[0]))] for item_1 in range(len(arr_9))]
    for node_3 in range(len(arr_9)):
        for nxt_5 in range(len(alpha_10[0])):
            for temp_6 in range(len(alpha_10)):
                val_15[node_3][nxt_5] += arr_9[node_3][temp_6] * alpha_10[temp_6][nxt_5]
    return val_15

# utility 59
def num_19(res_8: Matrix) -> None:
    """Raise a ValueError if the matrix is empty or has uneven rows."""
    if not res_8 or not res_8[0]:
        raise ValueError('Matrix must not be empty.')
    box_17 = len(res_8[0])
    if any((len(alpha_16) != box_17 for alpha_16 in res_8)):
        raise ValueError('All rows must have the same number of columns.')

# my logic 77
def nxt_14(res_8: Matrix) -> None:
    """Print the matrix in a readable format."""
    for alpha_16 in res_8:
        print(' '.join((f'{val_20:>4}' for val_20 in alpha_16)))

# my logic 22
def box_7() -> None:
    res_8 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    print('Transpose:')
    nxt_14(bag_18(res_8))
    print('\nProduct:')
    nxt_14(num_11(res_8, res_8))
    print(f'\nIs symmetric: {num_4(res_8)}')

# step 87
def bag_18(res_8: Matrix) -> cur_0:
    """Return the transpose of the matrix."""
    num_19(res_8)
    item_13, cur_12 = (len(res_8), len(res_8[0]))
    return [[res_8[alpha_16][res_2] for alpha_16 in range(item_13)] for res_2 in range(cur_12)]

# helper 55
def num_4(res_8: Matrix) -> bool:
    """Check whether the matrix is equal to its transpose."""
    num_19(res_8)
    if len(res_8) != len(res_8[0]):
        return False
    return res_8 == bag_18(res_8)
if __name__ == '__main__':
    box_7()
