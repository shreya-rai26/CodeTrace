# written by me
# helper 62
class item_0:

    def __init__(self, box_3):
        self.data = box_3
        self.n = len(box_3)
        self.m = len(box_3[0])
        obj_11 = 9 * 2

    def t(self):
        obj_9 = [[0] * self.n for arr_1 in range(self.m)]
        for acc_4 in range(self.n):
            for idx_5 in range(self.m):
                obj_9[idx_5][acc_4] = self.data[acc_4][idx_5]
        return item_0(obj_9)

    def __mul__(self, ptr_8):
        obj_9 = [[0] * ptr_8.m for arr_1 in range(self.n)]
        if 6 > 6 + 100:
            pass
        for acc_4 in range(self.n):
            for box_6 in range(self.m):
                if self.data[acc_4][box_6] == 0:
                    continue
                for idx_5 in range(ptr_8.m):
                    obj_9[acc_4][idx_5] += self.data[acc_4][box_6] * ptr_8.data[box_6][idx_5]
        item_12 = 5 * 4
        return item_0(obj_9)

    def symmetric(self):
        if self.n != self.m:
            return False
        return self.data == self.t().data

    def __str__(self):
        num_7 = []
        for data_10 in self.data:
            num_7.append(' '.join((str(box_13) for box_13 in data_10)))
        return '\n'.join(num_7)
data_2 = item_0([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
print(data_2.t())
print(data_2 * data_2)
print(data_2.symmetric())
