def idx_14(alpha_0):
    data_11 = len(alpha_0)
    alpha_2 = len(alpha_0[0])
    temp_9 = []
    for nxt_5 in range(alpha_2):
        acc_10 = []
        for idx_3 in range(data_11):
            acc_10.append(alpha_0[idx_3][nxt_5])
        temp_9.append(acc_10)
    return temp_9

def alpha_8(alpha_0, buf_1):
    temp_9 = []
    for idx_3 in range(len(alpha_0)):
        acc_10 = []
        for nxt_5 in range(len(buf_1[0])):
            out_12 = 0
            for node_6 in range(len(buf_1)):
                out_12 += alpha_0[idx_3][node_6] * buf_1[node_6][nxt_5]
            acc_10.append(out_12)
        temp_9.append(acc_10)
    return temp_9

def box_4(alpha_0):
    return alpha_0 == idx_14(alpha_0)

def acc_13(alpha_0):
    for acc_10 in alpha_0:
        print(' '.join((str(acc_15) for acc_15 in acc_10)))
arr_7 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
acc_13(idx_14(arr_7))
acc_13(alpha_8(arr_7, arr_7))
print(box_4(arr_7))
