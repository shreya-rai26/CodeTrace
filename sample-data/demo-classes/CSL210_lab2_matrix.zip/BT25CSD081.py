def res_6(ptr_11, item_15, cur_1):
    return ptr_11[item_15][cur_1]

def obj_4(ptr_11):
    val_0 = {}
    item_15 = 0
    while item_15 < len(ptr_11):
        cur_1 = 0
        while cur_1 < len(ptr_11[item_15]):
            val_0[cur_1, item_15] = res_6(ptr_11, item_15, cur_1)
            cur_1 += 1
        item_15 += 1
    return bag_17(val_0, len(ptr_11[0]), len(ptr_11))

def bag_17(node_2, val_8, temp_18):
    idx_7 = []
    for item_15 in range(val_8):
        idx_7.append([node_2[item_15, cur_1] for cur_1 in range(temp_18)])
    return idx_7

def arr_13(res_12, idx_14):
    node_2 = {}
    for item_15 in range(len(res_12)):
        for cur_1 in range(len(idx_14[0])):
            node_2[item_15, cur_1] = 0
            temp_9 = 0
            while temp_9 < len(idx_14):
                node_2[item_15, cur_1] = node_2[item_15, cur_1] + res_6(res_12, item_15, temp_9) * res_6(idx_14, temp_9, cur_1)
                temp_9 += 1
    return bag_17(node_2, len(res_12), len(idx_14[0]))

def val_16(ptr_11):
    node_5 = obj_4(ptr_11)
    for item_15 in range(len(ptr_11)):
        if ptr_11[item_15] != node_5[item_15]:
            return False
    return True
acc_3 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
for nxt_10 in obj_4(acc_3):
    print(*nxt_10)
for nxt_10 in arr_13(acc_3, acc_3):
    print(*nxt_10)
print(val_16(acc_3))
