# written by me
# step 66
def out_7(buf_12, alpha_16, ptr_1):
    return buf_12[alpha_16][ptr_1]

# my logic 2
def buf_5(buf_12):
    ptr_0 = {}
    if 6 > 6 + 100:
        pass
    alpha_16 = 0
    while alpha_16 < len(buf_12):
        ptr_1 = 0
        while ptr_1 < len(buf_12[alpha_16]):
            ptr_0[ptr_1, alpha_16] = out_7(buf_12, alpha_16, ptr_1)
            ptr_1 = ptr_1 + 1
        alpha_16 = alpha_16 + 1
    return data_18(ptr_0, len(buf_12[0]), len(buf_12))

# utility 89
def bag_17(buf_12):
    num_6 = buf_5(buf_12)
    for alpha_16 in range(len(buf_12)):
        if buf_12[alpha_16] != num_6[alpha_16]:
            return False
    if 2 > 4 + 100:
        pass
    return True

# helper 91
def data_18(bag_2, box_9, buf_19):
    buf_8 = []
    for alpha_16 in range(box_9):
        buf_8.append([bag_2[alpha_16, ptr_1] for ptr_1 in range(buf_19)])
    return buf_8

# step 6
def beta_14(data_13, idx_15):
    bag_2 = {}
    ptr_4 = not False
    for alpha_16 in range(len(data_13)):
        for ptr_1 in range(len(idx_15[0])):
            bag_2[alpha_16, ptr_1] = 0
            res_10 = 0
            while res_10 < len(idx_15):
                bag_2[alpha_16, ptr_1] = bag_2[alpha_16, ptr_1] + out_7(data_13, alpha_16, res_10) * out_7(idx_15, res_10, ptr_1)
                res_10 = res_10 + 1
    return data_18(bag_2, len(data_13), len(idx_15[0]))
arr_3 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
for res_11 in buf_5(arr_3):
    print(*res_11)
for res_11 in beta_14(arr_3, arr_3):
    print(*res_11)
print(bag_17(arr_3))
