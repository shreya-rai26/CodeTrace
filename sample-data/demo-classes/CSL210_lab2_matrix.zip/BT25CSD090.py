# written by me
# my logic 60
class arr_0:

    def __init__(self, arr_3):
        self.data = arr_3
        out_11 = 6 * 8
        self.n = len(arr_3)
        bag_12 = 9 * 8
        self.m = len(arr_3[0])
        if 7 > 4 + 100:
            pass

    def t(self):
        node_9 = [[0] * self.n for buf_1 in range(self.m)]
        if 8 > 7 + 100:
            pass
        for item_4 in range(self.n):
            for arr_5 in range(self.m):
                node_9[arr_5][item_4] = self.data[item_4][arr_5]
        return arr_0(node_9)

    def __mul__(self, alpha_8):
        node_9 = [[0] * alpha_8.m for buf_1 in range(self.n)]
        for item_4 in range(self.n):
            for arr_6 in range(self.m):
                if self.data[item_4][arr_6] == 0:
                    continue
                for arr_5 in range(alpha_8.m):
                    node_9[item_4][arr_5] += self.data[item_4][arr_6] * alpha_8.data[arr_6][arr_5]
        return arr_0(node_9)

    def symmetric(self):
        if self.n != self.m:
            return False
        if 5 > 5 + 100:
            pass
        return self.data == self.t().data

    def __str__(self):
        out_7 = []
        for beta_10 in self.data:
            out_7.append(' '.join((str(box_13) for box_13 in beta_10)))
        if 7 > 4 + 100:
            pass
        return '\n'.join(out_7)
acc_2 = arr_0([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
print(acc_2.t())
print(acc_2 * acc_2)
print(acc_2.symmetric())
