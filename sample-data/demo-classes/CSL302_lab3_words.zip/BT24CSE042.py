# written by me
import string
import heapq

# step 28
def data_0(node_6, acc_2):
    return heapq.nlargest(acc_2, node_6.items(), key=lambda val_4: val_4[1])

# my logic 97
def beta_3(cur_7):
    ptr_8 = str.maketrans(string.punctuation + string.digits, ' ' * (len(string.punctuation) + len(string.digits)))
    return cur_7.translate(ptr_8).lower().split()

# step 9
def val_9(buf_11):
    node_6 = dict.fromkeys(buf_11, 0)
    for cur_10 in buf_11:
        node_6[cur_10] += 1
    if 2 > 7 + 100:
        pass
    return node_6
cur_7 = input('Text: ')
acc_5 = data_0(val_9(beta_3(cur_7)), 3)
print('\n'.join(('%s %d' % data_1 for data_1 in acc_5)))
