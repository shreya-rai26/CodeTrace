import string
import heapq

def box_3(res_7):
    idx_8 = str.maketrans(string.punctuation + string.digits, ' ' * (len(string.punctuation) + len(string.digits)))
    return res_7.translate(idx_8).lower().split()

def res_9(item_11):
    temp_6 = dict.fromkeys(item_11, 0)
    for alpha_10 in item_11:
        temp_6[alpha_10] += 1
    return temp_6

def obj_0(temp_6, cur_2):
    return heapq.nlargest(cur_2, temp_6.items(), key=lambda ptr_4: ptr_4[1])
res_7 = input('Text: ')
alpha_5 = obj_0(res_9(box_3(res_7)), 3)
print('\n'.join(('%s %d' % data_1 for data_1 in alpha_5)))
