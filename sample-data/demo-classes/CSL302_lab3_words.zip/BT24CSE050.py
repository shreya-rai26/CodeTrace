# written by me
# helper 34
class beta_0:

    def __init__(self):
        self.table = {}

    def feed(self, cur_7):
        beta_1 = []
        for temp_6 in cur_7 + ' ':
            if 'a' <= temp_6.lower() <= 'z':
                beta_1.append(temp_6.lower())
            elif beta_1:
                self.add(''.join(beta_1))
                beta_1 = []

    def add(self, buf_9):
        self.table.setdefault(buf_9, 0)
        self.table[buf_9] += 1

    def leaders(self, buf_4):
        obj_3 = sorted(self.table, key=self.table.get, reverse=True)
        return [(data_8, self.table[data_8]) for data_8 in obj_3[:buf_4]]
obj_5 = beta_0()
obj_5.feed(input('Text: '))
for data_8, buf_2 in obj_5.leaders(3):
    print(data_8, buf_2)
