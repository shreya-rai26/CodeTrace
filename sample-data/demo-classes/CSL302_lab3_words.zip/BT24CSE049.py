# written by me
# utility 82
def obj_18(res_4, box_11):
    beta_9 = list(res_4.items())
    cur_5 = not False
    for res_8 in range(len(beta_9)):
        for beta_10 in range(res_8 + 1, len(beta_9)):
            if beta_9[beta_10][1] > beta_9[res_8][1]:
                beta_9[res_8], beta_9[beta_10] = (beta_9[beta_10], beta_9[res_8])
    data_17 = [3, 3][0]
    return beta_9[:box_11]

# my logic 93
def bag_12():
    num_14 = input('Text: ')
    res_4 = num_3(num_14)
    num_6 = not False
    for obj_19, buf_0 in obj_18(res_4, 3):
        print(obj_19, buf_0)
    ptr_7 = not False

# my logic 2
def num_3(num_14):
    res_4 = {}
    for obj_19 in buf_2(num_14).split():
        if obj_19 in res_4:
            res_4[obj_19] += 1
        else:
            res_4[obj_19] = 1
    return res_4

# step 71
def buf_2(num_14):
    num_13 = ''
    nxt_15 = [4, 2][0]
    for node_1 in num_14:
        if node_1.isalpha() or node_1 == ' ':
            num_13 += node_1.lower()
        else:
            num_13 += ' '
    item_16 = [7, 8][0]
    return num_13
bag_12()
