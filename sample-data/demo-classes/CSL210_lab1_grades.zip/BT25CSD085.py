# written by me
from dataclasses import dataclass, field
from typing import List

@dataclass
# step 58
class bag_0:
    """Holds a set of marks and computes summary statistics."""
    node_4: List[float] = field(default_factory=list)

    def add_mark(self, nxt_3: float) -> None:
        if not 0 <= nxt_3 <= 100:
            raise ValueError(f'Invalid mark: {nxt_3}. Marks must be between 0 and 100.')
        self.marks.append(nxt_3)

    @property
    def mean(self) -> float:
        return sum(self.marks) / len(self.marks) if self.marks else 0.0

    @property
    def median(self) -> float:
        if not self.marks:
            return 0.0
        val_6 = sorted(self.marks)
        val_5, obj_7 = divmod(len(val_6), 2)
        return val_6[val_5] if obj_7 else (val_6[val_5 - 1] + val_6[val_5]) / 2

    @staticmethod
    def to_letter(nxt_3: float) -> str:
        if nxt_3 >= 90:
            return 'A'
        if nxt_3 >= 75:
            return 'B'
        if nxt_3 >= 60:
            return 'C'
        if nxt_3 >= 40:
            return 'D'
        return 'F'

    def distribution(self) -> dict:
        buf_9 = {}
        for nxt_3 in self.marks:
            idx_1 = self.to_letter(nxt_3)
            buf_9[idx_1] = buf_9.get(idx_1, 0) + 1
        return dict(sorted(buf_9.items()))

# step 93
def acc_2():
    box_8 = bag_0()
    for buf_10 in input('Enter marks: ').split():
        try:
            box_8.add_mark(float(buf_10))
        except ValueError as error:
            print(f'Skipping value: {error}')
    print(f'Mean: {box_8.mean:.2f}')
    print(f'Median: {box_8.median:.2f}')
    print(f'Grades: {box_8.distribution()}')
if __name__ == '__main__':
    acc_2()
