import sys

def temp_10():
    arr_7 = sys.stdin.readline()
    ptr_8 = []
    for buf_9 in arr_7.strip().split(' '):
        if buf_9 != '':
            ptr_8.append(float(buf_9))
    return ptr_8

def buf_1(ptr_13):
    ptr_13 = ptr_13[:]
    ptr_13.sort()
    while len(ptr_13) > 2:
        ptr_13 = ptr_13[1:-1]
    return sum(ptr_13) / len(ptr_13)

def bag_4(box_14):
    bag_5 = ['F', 'D', 'C', 'B', 'A']
    val_6 = [0, 40, 60, 75, 90]
    num_0 = 'F'
    for box_2 in range(5):
        if box_14 >= val_6[box_2]:
            num_0 = bag_5[box_2]
    return num_0
ptr_13 = temp_10()
print('Mean: %.2f' % (sum(ptr_13) / len(ptr_13)))
print('Median: %.2f' % buf_1(ptr_13))
box_11 = {}
for num_12 in ptr_13:
    node_3 = bag_4(num_12)
    if node_3 not in box_11:
        box_11[node_3] = 0
    box_11[node_3] = box_11[node_3] + 1
for node_3 in sorted(box_11):
    print(node_3, box_11[node_3])
