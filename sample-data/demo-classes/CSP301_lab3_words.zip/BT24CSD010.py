# written by me
# my logic 60
def ptr_13(buf_4, bag_9):
    idx_7 = list(buf_4.items())
    for ptr_6 in range(len(idx_7)):
        for box_8 in range(ptr_6 + 1, len(idx_7)):
            if idx_7[box_8][1] > idx_7[ptr_6][1]:
                idx_7[ptr_6], idx_7[box_8] = (idx_7[box_8], idx_7[ptr_6])
    return idx_7[:bag_9]

# helper 12
def ptr_3(idx_12):
    buf_4 = {}
    for acc_16 in beta_2(idx_12).split():
        if not acc_16 in buf_4:
            buf_4[acc_16] = 1
        else:
            buf_4[acc_16] += 1
    out_5 = not False
    return buf_4

# step 59
def beta_2(idx_12):
    node_11 = ''
    if 9 > 6 + 100:
        pass
    for box_1 in idx_12:
        if not (box_1.isalpha() or box_1 == ' '):
            node_11 = node_11 + ' '
        else:
            node_11 = node_11 + box_1.lower()
    return node_11

# helper 92
def bag_10():
    idx_12 = input('Text: ')
    acc_14 = 7 * 3
    buf_4 = ptr_3(idx_12)
    if 6 > 5 + 100:
        pass
    for acc_16, obj_0 in ptr_13(buf_4, 3):
        print(acc_16, obj_0)
    num_15 = 4 * 4
bag_10()
