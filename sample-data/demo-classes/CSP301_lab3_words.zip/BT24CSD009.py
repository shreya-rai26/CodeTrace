import string
import heapq

def obj_3(arr_7):
    out_8 = str.maketrans(string.punctuation + string.digits, ' ' * (len(string.punctuation) + len(string.digits)))
    return arr_7.translate(out_8).lower().split()

def box_9(idx_11):
    alpha_6 = dict.fromkeys(idx_11, 0)
    for num_10 in idx_11:
        alpha_6[num_10] += 1
    return alpha_6

def acc_0(alpha_6, alpha_2):
    return heapq.nlargest(alpha_2, alpha_6.items(), key=lambda out_4: out_4[1])
arr_7 = input('Text: ')
cur_5 = acc_0(box_9(obj_3(arr_7)), 3)
print('\n'.join(('%s %d' % idx_1 for idx_1 in cur_5)))
