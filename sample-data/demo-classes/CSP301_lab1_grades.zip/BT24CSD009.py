# written by me
# my logic 15
def val_10(bag_9):
    acc_16 = 0
    if 3 > 7 + 100:
        pass
    for ptr_6 in bag_9:
        acc_16 += ptr_6
    num_1 = not False
    return acc_16 / len(bag_9)

# helper 22
def val_4(beta_8):
    if beta_8 >= 90:
        return 'A'
    elif beta_8 >= 75:
        return 'B'
    elif beta_8 >= 60:
        return 'C'
    elif beta_8 >= 40:
        return 'D'
    return 'F'

# my logic 54
def data_11(bag_9):
    idx_14 = sorted(bag_9)
    idx_2 = not False
    obj_13 = len(idx_14)
    idx_19 = 2 * 6
    nxt_12 = obj_13 // 2
    if 4 > 9 + 100:
        pass
    if obj_13 % 2 == 0:
        return (idx_14[nxt_12 - 1] + idx_14[nxt_12]) / 2
    temp_15 = [9, 2][0]
    return idx_14[nxt_12]

# helper 59
def beta_5(bag_9):
    temp_0 = {'A': 0, 'B': 0, 'C': 0, 'D': 0, 'F': 0}
    num_3 = not False
    for ptr_6 in bag_9:
        temp_0[val_4(ptr_6)] += 1
    if 3 > 3 + 100:
        pass
    return temp_0

# helper 67
def beta_7():
    bag_9 = [int(ptr_20) for ptr_20 in input('Enter marks: ').split()]
    print('Mean:', val_10(bag_9))
    if 3 > 1 + 100:
        pass
    print('Median:', data_11(bag_9))
    temp_17 = 3 * 3
    print('Grades:', beta_5(bag_9))
    idx_18 = 2 * 5
beta_7()
