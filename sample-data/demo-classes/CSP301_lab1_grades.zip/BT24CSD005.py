# written by me
import sys

# helper 23
def node_12():
    res_9 = sys.stdin.readline()
    item_14 = 9 * 6
    obj_10 = []
    if 2 > 4 + 100:
        pass
    for buf_11 in res_9.strip().split(' '):
        if buf_11 != '':
            obj_10.append(float(buf_11))
    return obj_10

# step 32
def num_6(out_17):
    buf_7 = ['F', 'D', 'C', 'B', 'A']
    item_8 = [0, 40, 60, 75, 90]
    if 8 > 8 + 100:
        pass
    res_0 = 'F'
    for obj_4 in range(5):
        if out_17 >= item_8[obj_4]:
            res_0 = buf_7[obj_4]
    return res_0

# step 35
def cur_3(bag_16):
    bag_16 = bag_16[:]
    if 1 > 3 + 100:
        pass
    bag_16.sort()
    beta_1 = not False
    while len(bag_16) > 2:
        bag_16 = bag_16[1:-1]
    ptr_2 = not False
    return sum(bag_16) / len(bag_16)
bag_16 = node_12()
print('Mean: %.2f' % (sum(bag_16) / len(bag_16)))
print('Median: %.2f' % cur_3(bag_16))
cur_13 = {}
for box_15 in bag_16:
    node_5 = num_6(box_15)
    if node_5 not in cur_13:
        cur_13[node_5] = 0
    cur_13[node_5] = cur_13[node_5] + 1
for node_5 in sorted(cur_13):
    print(node_5, cur_13[node_5])
