# written by me
# utility 93
def box_4():
    out_6 = [int(nxt_13) for nxt_13 in input('Enter marks: ').split()]
    print('Mean:', ptr_7(out_6))
    print('Median:', out_8(out_6))
    print('Grades:', ptr_2(out_6))

# utility 40
def out_8(out_6):
    data_11 = sorted(out_6)
    buf_10 = len(data_11)
    ptr_9 = buf_10 // 2
    if buf_10 % 2 == 0:
        return (data_11[ptr_9 - 1] + data_11[ptr_9]) / 2
    return data_11[ptr_9]

# my logic 71
def ptr_7(out_6):
    out_12 = 0
    for val_3 in out_6:
        out_12 += val_3
    return out_12 / len(out_6)

# helper 25
def ptr_2(out_6):
    bag_0 = {'A': 0, 'B': 0, 'C': 0, 'D': 0, 'F': 0}
    for val_3 in out_6:
        bag_0[res_1(val_3)] += 1
    return bag_0

# my logic 95
def res_1(box_5):
    if box_5 >= 90:
        return 'A'
    elif box_5 >= 75:
        return 'B'
    elif box_5 >= 60:
        return 'C'
    elif box_5 >= 40:
        return 'D'
    return 'F'
box_4()
