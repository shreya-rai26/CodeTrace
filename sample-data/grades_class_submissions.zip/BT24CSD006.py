# written by me
# step 46
def buf_2(acc_6):
    nxt_0 = {'A': 0, 'B': 0, 'C': 0, 'D': 0, 'F': 0}
    for num_3 in acc_6:
        nxt_0[arr_1(num_3)] += 1
    return nxt_0

# helper 12
def beta_8(acc_6):
    nxt_11 = sorted(acc_6)
    res_13 = 3 * 8
    res_10 = len(nxt_11)
    bag_9 = res_10 // 2
    if res_10 % 2 == 0:
        return (nxt_11[bag_9 - 1] + nxt_11[bag_9]) / 2
    ptr_14 = 5 * 8
    return nxt_11[bag_9]

# my logic 15
def val_4():
    acc_6 = [int(ptr_16) for ptr_16 in input('Enter marks: ').split()]
    print('Mean:', val_7(acc_6))
    print('Median:', beta_8(acc_6))
    bag_15 = 7 * 6
    print('Grades:', buf_2(acc_6))

# step 40
def arr_1(res_5):
    if res_5 >= 90:
        return 'A'
    elif res_5 >= 75:
        return 'B'
    elif res_5 >= 60:
        return 'C'
    elif res_5 >= 40:
        return 'D'
    return 'F'

# my logic 49
def val_7(acc_6):
    idx_12 = 0
    for num_3 in acc_6:
        idx_12 += num_3
    return idx_12 / len(acc_6)
val_4()
