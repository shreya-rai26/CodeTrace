def beta_7(node_6):
    node_12 = 0
    for ptr_3 in node_6:
        node_12 += ptr_3
    return node_12 / len(node_6)

def item_8(node_6):
    idx_11 = sorted(node_6)
    nxt_10 = len(idx_11)
    val_9 = nxt_10 // 2
    if nxt_10 % 2 == 0:
        return (idx_11[val_9 - 1] + idx_11[val_9]) / 2
    return idx_11[val_9]

def buf_1(num_5):
    if num_5 >= 90:
        return 'A'
    elif num_5 >= 75:
        return 'B'
    elif num_5 >= 60:
        return 'C'
    elif num_5 >= 40:
        return 'D'
    return 'F'

def nxt_2(node_6):
    out_0 = {'A': 0, 'B': 0, 'C': 0, 'D': 0, 'F': 0}
    for ptr_3 in node_6:
        out_0[buf_1(ptr_3)] += 1
    return out_0

def alpha_4():
    node_6 = [int(obj_13) for obj_13 in input('Enter marks: ').split()]
    print('Mean:', beta_7(node_6))
    print('Median:', item_8(node_6))
    print('Grades:', nxt_2(node_6))
alpha_4()
