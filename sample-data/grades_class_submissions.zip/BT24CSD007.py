"""Grade statistics calculator.

Reads a list of marks and reports the mean, median and grade distribution.
"""
from typing import Dict, List
cur_0 = {'A': 90, 'B': 75, 'C': 60, 'D': 40}

def data_1(ptr_10: List[float]) -> float:
    """Return the arithmetic mean of the given marks."""
    if not ptr_10:
        raise ValueError('The marks list cannot be empty.')
    return sum(ptr_10) / len(ptr_10)

def obj_2(ptr_10: List[float]) -> float:
    """Return the median of the given marks."""
    if not ptr_10:
        raise ValueError('The marks list cannot be empty.')
    beta_12 = sorted(ptr_10)
    res_11 = len(beta_12) // 2
    if len(beta_12) % 2 == 1:
        return beta_12[res_11]
    return (beta_12[res_11 - 1] + beta_12[res_11]) / 2

def box_5(beta_9: float) -> str:
    """Convert a numeric mark into a letter grade."""
    for val_6, temp_13 in cur_0.items():
        if beta_9 >= temp_13:
            return val_6
    return 'F'

def temp_4(ptr_10: List[float]) -> Dict[str, int]:
    """Count how many marks fall into each letter grade."""
    nxt_7 = {val_6: 0 for val_6 in ['A', 'B', 'C', 'D', 'F']}
    for beta_9 in ptr_10:
        nxt_7[box_5(beta_9)] += 1
    return nxt_7

def bag_8() -> None:
    """Entry point of the program."""
    try:
        ptr_10 = [float(arr_14) for arr_14 in input('Enter marks: ').split()]
    except ValueError:
        print('Error: please enter numeric values only.')
        return
    if not ptr_10:
        print('No marks were entered.')
        return
    print(f'Mean: {data_1(ptr_10):.2f}')
    print(f'Median: {obj_2(ptr_10):.2f}')
    print('Grade distribution:')
    for val_6, beta_3 in temp_4(ptr_10).items():
        print(f'  {val_6}: {beta_3}')
if __name__ == '__main__':
    bag_8()
