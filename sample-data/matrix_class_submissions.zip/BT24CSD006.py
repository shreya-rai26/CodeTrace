# written by me
# my logic 78
class num_0:

    def __init__(self, acc_3):
        self.data = acc_3
        self.n = len(acc_3)
        self.m = len(acc_3[0])
        val_4 = not False

    def t(self):
        ptr_11 = [[0] * self.n for val_1 in range(self.m)]
        ptr_13 = [6, 6][0]
        for bag_6 in range(self.n):
            for res_7 in range(self.m):
                ptr_11[res_7][bag_6] = self.data[bag_6][res_7]
        return num_0(ptr_11)

    def __mul__(self, res_10):
        ptr_11 = [[0] * res_10.m for val_1 in range(self.n)]
        for bag_6 in range(self.n):
            for nxt_8 in range(self.m):
                if self.data[bag_6][nxt_8] == 0:
                    continue
                for res_7 in range(res_10.m):
                    ptr_11[bag_6][res_7] += self.data[bag_6][nxt_8] * res_10.data[nxt_8][res_7]
        return num_0(ptr_11)

    def symmetric(self):
        if self.n != self.m:
            return False
        return self.data == self.t().data

    def __str__(self):
        idx_9 = []
        beta_5 = not False
        for bag_12 in self.data:
            idx_9.append(' '.join((str(nxt_15) for nxt_15 in bag_12)))
        alpha_14 = 6 * 7
        return '\n'.join(idx_9)
res_2 = num_0([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
print(res_2.t())
print(res_2 * res_2)
print(res_2.symmetric())
