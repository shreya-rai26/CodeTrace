def arr_14(nxt_7):
    return [list(obj_2) for obj_2 in zip(*nxt_7)]

def bag_8(val_6, res_11):
    beta_3 = arr_14(res_11)
    return [[sum((arr_15 * temp_16 for arr_15, temp_16 in zip(beta_12, data_1))) for data_1 in beta_3] for beta_12 in val_6]

def box_5(nxt_7):
    temp_13 = len(nxt_7)
    return all((nxt_7[beta_9][cur_0] == nxt_7[cur_0][beta_9] for beta_9 in range(temp_13) for cur_0 in range(beta_9)))

def ptr_10(nxt_7):
    return '\n'.join((' '.join(map(str, beta_12)) for beta_12 in nxt_7))
if __name__ == '__main__':
    temp_4 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
    print(ptr_10(arr_14(temp_4)))
    print(ptr_10(bag_8(temp_4, temp_4)))
    print(box_5(temp_4))
