# written by me
# utility 59
class node_0:
    """A small helper class that groups common matrix operations."""

    def __init__(self, alpha_12):
        if not alpha_12:
            raise ValueError('Matrix cannot be empty')
        self.rows = [list(obj_11) for obj_11 in alpha_12]
        self.row_count = len(self.rows)
        self.col_count = len(self.rows[0])

    def transpose(self):
        return node_0(zip(*self.rows))

    def multiply(self, node_8):
        if self.col_count != node_8.row_count:
            raise ValueError('Incompatible dimensions for multiplication')
        ptr_9 = list(zip(*node_8.rows))
        res_10 = []
        for obj_11 in self.rows:
            data_7 = []
            for data_3 in ptr_9:
                data_7.append(sum((nxt_1 * obj_2 for nxt_1, obj_2 in zip(obj_11, data_3))))
            res_10.append(data_7)
        return node_0(res_10)

    def is_symmetric(self):
        if self.row_count != self.col_count:
            return False
        for res_4 in range(self.row_count):
            for beta_5 in range(res_4 + 1, self.col_count):
                if self.rows[res_4][beta_5] != self.rows[beta_5][res_4]:
                    return False
        return True

    def __repr__(self):
        return '\n'.join(('\t'.join((str(num_13) for num_13 in obj_11)) for obj_11 in self.rows))
if __name__ == '__main__':
    temp_6 = node_0([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
    print('Transpose:')
    print(temp_6.transpose())
    print('Product:')
    print(temp_6.multiply(temp_6))
    print('Symmetric:', temp_6.is_symmetric())
