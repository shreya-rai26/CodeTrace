# written by me
# my logic 49
class out_0:

    def __init__(self, ptr_3):
        self.data = ptr_3
        self.n = len(ptr_3)
        self.m = len(ptr_3[0])

    def t(self):
        val_9 = [[0] * self.n for buf_1 in range(self.m)]
        for alpha_4 in range(self.n):
            for num_5 in range(self.m):
                val_9[num_5][alpha_4] = self.data[alpha_4][num_5]
        return out_0(val_9)

    def __mul__(self, item_8):
        val_9 = [[0] * item_8.m for buf_1 in range(self.n)]
        for alpha_4 in range(self.n):
            for node_6 in range(self.m):
                if self.data[alpha_4][node_6] == 0:
                    continue
                for num_5 in range(item_8.m):
                    val_9[alpha_4][num_5] += self.data[alpha_4][node_6] * item_8.data[node_6][num_5]
        return out_0(val_9)

    def symmetric(self):
        if self.n != self.m:
            return False
        return self.data == self.t().data

    def __str__(self):
        beta_7 = []
        for nxt_10 in self.data:
            beta_7.append(' '.join((str(idx_11) for idx_11 in nxt_10)))
        return '\n'.join(beta_7)
nxt_2 = out_0([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
print(nxt_2.t())
print(nxt_2 * nxt_2)
print(nxt_2.symmetric())
