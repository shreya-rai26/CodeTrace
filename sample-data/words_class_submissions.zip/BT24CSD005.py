# written by me
# helper 74
class num_0:

    def __init__(self):
        self.table = {}

    def feed(self, node_7):
        node_1 = []
        for idx_6 in node_7 + ' ':
            if 'a' <= idx_6.lower() <= 'z':
                node_1.append(idx_6.lower())
            elif node_1:
                self.add(''.join(node_1))
                node_1 = []

    def add(self, box_9):
        self.table.setdefault(box_9, 0)
        self.table[box_9] += 1

    def leaders(self, val_4):
        item_3 = sorted(self.table, key=self.table.get, reverse=True)
        return [(obj_8, self.table[obj_8]) for obj_8 in item_3[:val_4]]
nxt_5 = num_0()
nxt_5.feed(input('Text: '))
for obj_8, beta_2 in nxt_5.leaders(3):
    print(obj_8, beta_2)
